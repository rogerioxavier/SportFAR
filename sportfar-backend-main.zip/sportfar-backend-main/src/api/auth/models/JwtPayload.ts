export class JwtPayload {
  username: string;
  sub: string;
}
